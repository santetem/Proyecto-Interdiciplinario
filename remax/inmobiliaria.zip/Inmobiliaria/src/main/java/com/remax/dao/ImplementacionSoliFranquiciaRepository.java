//21. SoliFranquiciaRepository.java
package com.remax.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.remax.model.SoliFranquicia;

@Repository
public interface ImplementacionSoliFranquiciaRepository extends JpaRepository<SoliFranquicia, Long> {}

